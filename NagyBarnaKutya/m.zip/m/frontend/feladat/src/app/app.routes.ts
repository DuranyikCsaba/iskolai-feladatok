import { Routes } from '@angular/router';
import { NavComponent } from './nav/nav.component';
import { PostComponent } from './post/post.component';
import { GetComponent } from './get/get.component';

export const routes: Routes = [
  {  path: '', component: NavComponent },
  {  path: 'post', component: PostComponent },
  {  path: 'get', component: GetComponent }
];
