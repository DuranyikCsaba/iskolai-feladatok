import { Component } from '@angular/core';

@Component({
  selector: 'app-get',
  imports: [],
  templateUrl: './get.component.html',
  styleUrl: './get.component.css'
})
export class GetComponent {

}
